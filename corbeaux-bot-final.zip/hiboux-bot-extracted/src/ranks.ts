import { readFileSync, writeFileSync, existsSync, mkdirSync } from "fs";
import { join, dirname } from "path";
import { fileURLToPath } from "url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const DATA_DIR = join(__dirname, "..", "data");
const FILE = join(DATA_DIR, "ranks.json");

export interface RankEntry {
  userId: string;
  userTag: string;
  points: number;
  level: number;
  lastMessageAt: string;
}

const POINTS_PER_MESSAGE = 10;
const COOLDOWN_MS = 60_000; // 1 minute entre chaque gain de points
const POINTS_PER_LEVEL = 100; // Points nécessaires pour monter de level

const lastMessageCooldown = new Map<string, number>();

function ensureDir(): void {
  if (!existsSync(DATA_DIR)) mkdirSync(DATA_DIR, { recursive: true });
}

function load(): RankEntry[] {
  ensureDir();
  if (!existsSync(FILE)) return [];
  try { return JSON.parse(readFileSync(FILE, "utf-8")) as RankEntry[]; } catch { return []; }
}

function save(list: RankEntry[]): void {
  ensureDir();
  writeFileSync(FILE, JSON.stringify(list, null, 2), "utf-8");
}

export function getRank(userId: string): RankEntry | null {
  return load().find(r => r.userId === userId) ?? null;
}

export function getLeaderboard(limit = 10): RankEntry[] {
  return load()
    .sort((a, b) => b.points - a.points || b.level - a.level)
    .slice(0, limit);
}

export function addPoints(userId: string, userTag: string): { gained: boolean; levelUp: boolean; newLevel: number } {
  const now = Date.now();
  const lastMsg = lastMessageCooldown.get(userId) ?? 0;

  if (now - lastMsg < COOLDOWN_MS) {
    return { gained: false, levelUp: false, newLevel: 0 };
  }

  lastMessageCooldown.set(userId, now);

  const list = load();
  let entry = list.find(r => r.userId === userId);
  if (!entry) {
    entry = { userId, userTag, points: 0, level: 1, lastMessageAt: new Date().toISOString() };
    list.push(entry);
  }

  entry.userTag = userTag;
  entry.points += POINTS_PER_MESSAGE;
  entry.lastMessageAt = new Date().toISOString();

  const newLevel = Math.floor(entry.points / POINTS_PER_LEVEL) + 1;
  const levelUp = newLevel > entry.level;
  entry.level = newLevel;

  save(list);
  return { gained: true, levelUp, newLevel };
}

export function setPoints(userId: string, userTag: string, points: number): void {
  const list = load();
  let entry = list.find(r => r.userId === userId);
  if (!entry) {
    entry = { userId, userTag, points, level: 1, lastMessageAt: new Date().toISOString() };
    list.push(entry);
  } else {
    entry.points = points;
    entry.userTag = userTag;
  }
  entry.level = Math.floor(points / POINTS_PER_LEVEL) + 1;
  save(list);
}

export function getRankPosition(userId: string): number {
  const sorted = load().sort((a, b) => b.points - a.points);
  const idx = sorted.findIndex(r => r.userId === userId);
  return idx === -1 ? -1 : idx + 1;
}

export const POINTS_PER_LEVEL_EXPORT = POINTS_PER_LEVEL;
