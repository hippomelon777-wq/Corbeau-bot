import {
  Client,
  GatewayIntentBits,
  Partials,
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  Events,
  REST,
  Routes,
  SlashCommandBuilder,
  TextChannel,
  PermissionFlagsBits,
  ChannelType,
  MessageFlags,
  type Interaction,
  type Guild,
  type GuildMember,
  type Message,
  Collection,
} from "discord.js";

import { isBlacklisted, addToBlacklist, removeFromBlacklist, getBlacklist } from "./blacklist.js";
import { getWarnings, addWarning, removeWarning, clearWarnings, generateWarnId } from "./warnings.js";
import { getWhitelist, isWhitelisted, addToWhitelist, removeFromWhitelist } from "./whitelist.js";
import { getOwners, isOwner, addOwner, removeOwner } from "./owners.js";
import { getConfig, updateConfig } from "./data.js";
import { handleAntiSpam, handleAntiRaid, disableRaidLockdown, isRaidLockdown } from "./antispam.js";
import { createBackup, listBackups, loadBackup } from "./backup.js";

const TOKEN = process.env["DISCORD_BOT_TOKEN"];
const ROLE_ID = process.env["ROLE_ID"];

if (!TOKEN) throw new Error("DISCORD_BOT_TOKEN environment variable is required.");
if (!ROLE_ID) throw new Error("ROLE_ID environment variable is required.");

// ══════════════════════════════════════════════════════════════════════════════
// SYSTÈME DE PERMISSIONS
// ══════════════════════════════════════════════════════════════════════════════
// Perm 5 : @paix        → owner bot (tout)
// Perm 4 : @admin       → administration complète
// Perm 3 : @+++  (chef modo)  → chef modérateur
// Perm 2 : @++   (modérateur) → modérateur
// Perm 1 : @+    (helpeur)    → helpeur / staff de base

const ROLE_LEVELS: Record<string, number> = {
  "+":     1,
  "++":    2,
  "+++":   3,
  "admin": 4,
  "paix":  5,
};

// Compatibilité anciens rôles
const ROLE_COMPAT: Record<string, number> = {
  "helpeur":      1,
  "Modérateurs":  2,
};

const PERM_LABELS: Record<number, string> = {
  1: "🟢 Perm 1 — Helpeur (@+)",
  2: "🔵 Perm 2 — Modérateur (@++)",
  3: "🟡 Perm 3 — Chef Modo (@+++)",
  4: "🔴 Perm 4 — Admin (@admin)",
  5: "⚫ Perm 5 — Paix (@paix)",
};

async function getPermLevel(guild: Guild, userId: string): Promise<number> {
  if (isOwner(userId)) return 5;
  const member = guild.members.cache.get(userId) ?? await guild.members.fetch(userId).catch(() => null);
  if (!member) return 0;
  let level = 0;
  for (const [roleName, roleLevel] of [...Object.entries(ROLE_LEVELS), ...Object.entries(ROLE_COMPAT)]) {
    const role = guild.roles.cache.find(r => r.name === roleName);
    if (role && member.roles.cache.has(role.id)) level = Math.max(level, roleLevel);
  }
  return level;
}

// ══════════════════════════════════════════════════════════════════════════════
// EMBED HELPERS
// ══════════════════════════════════════════════════════════════════════════════
const COLOR = {
  red: 0xe74c3c,
  green: 0x2ecc71,
  blue: 0x5865f2,
  orange: 0xe67e22,
  yellow: 0xf1c40f,
  purple: 0x9b59b6,
  dark: 0x2c2f33,
  grey: 0x95a5a6,
  darkred: 0x8b0000,
  white: 0xffffff,
};

function errEmbed(description: string): EmbedBuilder {
  return new EmbedBuilder().setColor(COLOR.red).setDescription(`❌ ${description}`).setTimestamp();
}

function okEmbed(title: string, description: string): EmbedBuilder {
  return new EmbedBuilder().setColor(COLOR.green).setTitle(title).setDescription(description).setTimestamp();
}

function successEmbed(msg = "La commande a été effectuée avec succès."): EmbedBuilder {
  return new EmbedBuilder().setColor(COLOR.green).setDescription(`✅ ${msg}`).setTimestamp();
}

function infoEmbed(title: string, description: string): EmbedBuilder {
  return new EmbedBuilder().setColor(COLOR.blue).setTitle(title).setDescription(description).setTimestamp();
}

function confirmRow(confirmId: string, label: string): ActionRowBuilder<ButtonBuilder> {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId(confirmId).setLabel(label).setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId("cancel_confirm").setLabel("❌ Annuler").setStyle(ButtonStyle.Secondary),
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// LOG HELPER
// ══════════════════════════════════════════════════════════════════════════════
async function sendLog(guild: Guild, channelName: string, embed: EmbedBuilder): Promise<void> {
  const channel = guild.channels.cache.find(c => c.name === channelName && c instanceof TextChannel);
  if (channel instanceof TextChannel) await channel.send({ embeds: [embed] }).catch(() => null);
}

// ══════════════════════════════════════════════════════════════════════════════
// HELP PAGES — Message permanent avec navigation
// ══════════════════════════════════════════════════════════════════════════════
function buildHelpPages(): EmbedBuilder[] {
  const footer = { text: "Corbeaux Bot v2.0 • Utilisez les boutons pour naviguer" };

  // ── Page 1 : Présentation & Sanctions légères ────────────────────────────
  const p1 = new EmbedBuilder()
    .setColor(COLOR.purple)
    .setTitle("🦉 Corbeaux + — Page 1/5 · Présentation")
    .setDescription("Bienvenue sur le menu d'aide du Corbeaux + !\n\n**Niveaux de permission :**")
    .addFields(
      { name: "🟢 Perm 1 — Helpeur (@+)", value: "Staff de base : warn, unwarn, warnlist, mute, unmute.", inline: false },
      { name: "🔵 Perm 2 — Modérateur (@++)", value: "Kick, ban, unban.", inline: false },
      { name: "🟡 Perm 3 — Chef Modo (@+++)", value: "Clear (purge de messages). Accès au /rank.", inline: false },
      { name: "🔴 Perm 4 — Admin (@admin)", value: "Lock, unlock, renew, blacklist, tickets, règles, backup, maintenance, whitelist.", inline: false },
      { name: "⚫ Perm 5 — Paix (@paix)", value: "Antilink, antispam, antiraid, owner. Accès total.", inline: false },
      { name: "⬜ Perm 0 — Tout le monde", value: "/help, /perm, /rank (voir son propre rang)", inline: false },
    )
    .setFooter(footer);

  // ── Page 2 : Modération (warns, mute) ───────────────────────────────────
  const p2 = new EmbedBuilder()
    .setColor(COLOR.yellow)
    .setTitle("⚠️ Aide — Page 2/5 · Sanctions (Perm 1+)")
    .setDescription("Commandes réservées aux **Helpeurs** et au staff supérieur.")
    .addFields(
      { name: "/warn @membre [raison]", value: "Donner un avertissement. Log dans `⚙️・logs•mute•unmute`.", inline: false },
      { name: "/unwarn @membre [id]", value: "Retirer un warn spécifique ou tous (laisser vide). Log dans `⚙️・logs•mute•unmute`.", inline: false },
      { name: "/warnlist @membre", value: "Voir la liste des avertissements d'un membre.", inline: false },
      { name: "/mute @membre durée unité [raison]", value: "Muter un membre (max 28 jours). Log dans `⚙️・logs•mute•unmute`.", inline: false },
      { name: "/unmute @membre", value: "Démuter un membre. Log dans `⚙️・logs•mute•unmute`.", inline: false },
    )
    .setFooter(footer);

  // ── Page 3 : Modération (kick/ban + clear) ───────────────────────────────
  const p3 = new EmbedBuilder()
    .setColor(COLOR.red)
    .setTitle("⚔️ Aide — Page 3/5 · Sanctions (Perm 2+ / 3+)")
    .setDescription("Commandes réservées aux **Modérateurs** et **Chefs Modo**.")
    .addFields(
      { name: "🔵 Perm 2+ — Modérateur", value: "\u200b", inline: false },
      { name: "/kick @membre [raison]", value: "Expulser un membre. Log dans `⚙️・logs`.", inline: false },
      { name: "/ban @membre [raison]", value: "Bannir un membre. Log dans `⚙️・logs`.", inline: false },
      { name: "/unban id [raison]", value: "Débannir par ID. Log dans `⚙️・logs`.", inline: false },
      { name: "\u200b", value: "\u200b", inline: false },
      { name: "🟡 Perm 3+ — Chef Modo", value: "\u200b", inline: false },
      { name: "/clear [nombre] [@membre]", value: "Supprimer 1 à 100 messages. Filtre optionnel par membre. Log dans `⚙️・logs`.", inline: false },
    )
    .setFooter(footer);

  // ── Page 4 : Admin (salons, blacklist, tickets) ──────────────────────────
  const p4 = new EmbedBuilder()
    .setColor(COLOR.blue)
    .setTitle("🔒 Aide — Page 4/5 · Administration (Perm 4+)")
    .setDescription("Commandes réservées aux **Admins**.")
    .addFields(
      { name: "Gestion des salons", value: "\u200b", inline: false },
      { name: "/lock [#salon] [raison]", value: "Verrouiller un salon. Log dans `⚙️・logs`.", inline: false },
      { name: "/unlock [#salon]", value: "Déverrouiller un salon. Log dans `⚙️・logs`.", inline: false },
      { name: "/renew [raison]", value: "Renouveler le salon actuel. Log dans `⚙️・logs`.", inline: false },
      { name: "\u200b", value: "\u200b", inline: false },
      { name: "Blacklist & Bans", value: "\u200b", inline: false },
      { name: "/bl @membre [raison]", value: "Blacklister + bannir. Log dans `⚙️・logs•bl`.", inline: false },
      { name: "/unbl id", value: "Retirer de la blacklist. Log dans `⚙️・logs•bl`.", inline: false },
      { name: "/blcheck", value: "Voir toute la blacklist.", inline: false },
      { name: "/banlist", value: "Voir tous les bans actifs.", inline: false },
      { name: "\u200b", value: "\u200b", inline: false },
      { name: "Tickets & Règles", value: "\u200b", inline: false },
      { name: "/ticket-deban", value: "Poster le panel de demande de déban.", inline: false },
      { name: "/ticket-proposition", value: "Poster le panel de proposition de stream.", inline: false },
      { name: "/règles", value: "Poster le règlement avec bouton d'acceptation.", inline: false },
      { name: "\u200b", value: "\u200b", inline: false },
      { name: "Whitelist & Backup", value: "\u200b", inline: false },
      { name: "/wl add id tag", value: "Ajouter à la whitelist (exempté des filtres auto).", inline: false },
      { name: "/wl remove id", value: "Retirer de la whitelist.", inline: false },
      { name: "/wl check", value: "Voir toute la whitelist.", inline: false },
      { name: "/backup create / list / load", value: "Gérer les sauvegardes complètes.", inline: false },
      { name: "/maintenance on|off", value: "Activer/désactiver le mode maintenance.", inline: false },
    )
    .setFooter(footer);

  // ── Page 5 : Sécurité & Owner ─────────────────────────────────────────────
  const p5 = new EmbedBuilder()
    .setColor(COLOR.yellow)
    .setTitle("🛡️ Aide — Page 5/5 · Sécurité & Owner (Perm 5)")
    .setDescription("Commandes réservées au **@paix** (owner bot).")
    .addFields(
      { name: "Protections automatiques", value: "\u200b", inline: false },
      { name: "/antilink on|off", value: "Filtre auto des liens. Log dans `⚙️・logs`.", inline: false },
      { name: "/antispam on|off [seuil] [intervalle]", value: "Détecte et mute les spammeurs. Log dans `⚙️・logs`.", inline: false },
      { name: "/antiraid on|off [seuil]", value: "Lockdown auto si vague de joins. Log dans `⚙️・logs`.", inline: false },
      { name: "/antiraid-reset", value: "Désactiver le lockdown manuellement.", inline: false },
      { name: "\u200b", value: "\u200b", inline: false },
      { name: "Gestion des Owners", value: "\u200b", inline: false },
      { name: "/owner add id tag", value: "Ajouter un owner bot (perm 5 permanente).", inline: false },
      { name: "/owner remove id", value: "Retirer un owner.", inline: false },
      { name: "/owner list", value: "Voir la liste des owners.", inline: false },
    )
    .setFooter(footer);

  return [p1, p2, p3, p4, p5];
}

function helpNavRow(currentPage: number, totalPages: number): ActionRowBuilder<ButtonBuilder> {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(`help_prev_${currentPage}`)
      .setLabel("◀ Précédent")
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(currentPage === 0),
    new ButtonBuilder()
      .setCustomId("help_page_info")
      .setLabel(`${currentPage + 1} / ${totalPages}`)
      .setStyle(ButtonStyle.Primary)
      .setDisabled(true),
    new ButtonBuilder()
      .setCustomId(`help_next_${currentPage}`)
      .setLabel("Suivant ▶")
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(currentPage === totalPages - 1),
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// IN-MEMORY CACHES
// ══════════════════════════════════════════════════════════════════════════════
interface PropositionData {
  nomRencontre: string;
  heure: string;
  chaine: string;
  sport: string;
  userId: string;
  userTag: string;
  userAvatar: string;
}
const propositionCache = new Map<string, PropositionData>();
const debanTicketCache = new Map<string, string>();

// ══════════════════════════════════════════════════════════════════════════════
// CLIENT
// ══════════════════════════════════════════════════════════════════════════════
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildModeration,
  ],
  partials: [Partials.Channel, Partials.Message],
});

// ══════════════════════════════════════════════════════════════════════════════
// COMMANDS DEFINITION
// ══════════════════════════════════════════════════════════════════════════════
const commands = [
  // Accessible à tous
  new SlashCommandBuilder().setName("help").setDescription("Afficher la liste de toutes les commandes disponibles"),
  new SlashCommandBuilder().setName("perm").setDescription("Voir les niveaux de permission"),

  // Perm 1+ (Helpeur)
  new SlashCommandBuilder()
    .setName("warn")
    .setDescription("Donner un avertissement à un membre")
    .addUserOption(o => o.setName("membre").setDescription("Membre à avertir").setRequired(true))
    .addStringOption(o => o.setName("raison").setDescription("Raison").setRequired(false)),

  new SlashCommandBuilder()
    .setName("unwarn")
    .setDescription("Retirer un ou tous les avertissements d'un membre")
    .addUserOption(o => o.setName("membre").setDescription("Membre").setRequired(true))
    .addStringOption(o => o.setName("id").setDescription("ID du warn (laisser vide = tout supprimer)").setRequired(false)),

  new SlashCommandBuilder()
    .setName("warnlist")
    .setDescription("Voir les avertissements d'un membre")
    .addUserOption(o => o.setName("membre").setDescription("Membre").setRequired(true)),

  new SlashCommandBuilder()
    .setName("mute")
    .setDescription("Muter (timeout) un membre")
    .addUserOption(o => o.setName("membre").setDescription("Membre à muter").setRequired(true))
    .addStringOption(o => o.setName("duree").setDescription("Valeur de la durée (ex: 10)").setRequired(true))
    .addStringOption(o =>
      o.setName("unite").setDescription("Unité de temps").setRequired(true)
        .addChoices(
          { name: "Secondes", value: "secondes" },
          { name: "Minutes", value: "minutes" },
          { name: "Heures", value: "heures" },
          { name: "Jours", value: "jours" },
        )
    )
    .addStringOption(o => o.setName("raison").setDescription("Raison").setRequired(false)),

  new SlashCommandBuilder()
    .setName("unmute")
    .setDescription("Retirer le mute d'un membre")
    .addUserOption(o => o.setName("membre").setDescription("Membre à démuter").setRequired(true)),

  // Perm 2+ (Modérateur)
  new SlashCommandBuilder()
    .setName("kick")
    .setDescription("Expulser un membre")
    .addUserOption(o => o.setName("membre").setDescription("Membre à expulser").setRequired(true))
    .addStringOption(o => o.setName("raison").setDescription("Raison").setRequired(false)),

  new SlashCommandBuilder()
    .setName("ban")
    .setDescription("Bannir un membre")
    .addUserOption(o => o.setName("membre").setDescription("Membre à bannir").setRequired(true))
    .addStringOption(o => o.setName("raison").setDescription("Raison").setRequired(false)),

  new SlashCommandBuilder()
    .setName("unban")
    .setDescription("Débannir un utilisateur par ID")
    .addStringOption(o => o.setName("id").setDescription("ID de l'utilisateur").setRequired(true))
    .addStringOption(o => o.setName("raison").setDescription("Raison").setRequired(false)),

  // Perm 3+ (Chef Modo)
  new SlashCommandBuilder()
    .setName("clear")
    .setDescription("Supprimer des messages dans le salon")
    .addIntegerOption(o => o.setName("nombre").setDescription("Nombre de messages (1-100)").setRequired(true).setMinValue(1).setMaxValue(100))
    .addUserOption(o => o.setName("membre").setDescription("Supprimer uniquement les messages de ce membre").setRequired(false)),

  // Perm 4+ (Admin)
  new SlashCommandBuilder()
    .setName("lock")
    .setDescription("Verrouiller un salon")
    .addChannelOption(o => o.setName("salon").setDescription("Salon à verrouiller (défaut: actuel)").setRequired(false))
    .addStringOption(o => o.setName("raison").setDescription("Raison").setRequired(false)),

  new SlashCommandBuilder()
    .setName("unlock")
    .setDescription("Déverrouiller un salon")
    .addChannelOption(o => o.setName("salon").setDescription("Salon à déverrouiller (défaut: actuel)").setRequired(false)),

  new SlashCommandBuilder()
    .setName("renew")
    .setDescription("Renouveler le salon actuel (supprime et recrée à l'identique)")
    .addStringOption(o => o.setName("raison").setDescription("Raison").setRequired(false)),

  new SlashCommandBuilder().setName("règles").setDescription("Envoie le règlement du serveur"),
  new SlashCommandBuilder().setName("ticket-deban").setDescription("Poster le panel de demande de déban"),
  new SlashCommandBuilder().setName("ticket-proposition").setDescription("Poster le panel de proposition de stream"),

  new SlashCommandBuilder()
    .setName("bl")
    .setDescription("Blacklister et bannir un membre")
    .addUserOption(o => o.setName("membre").setDescription("Membre à blacklister").setRequired(true))
    .addStringOption(o => o.setName("raison").setDescription("Raison").setRequired(false)),

  new SlashCommandBuilder()
    .setName("unbl")
    .setDescription("Retirer un utilisateur de la blacklist")
    .addStringOption(o => o.setName("id").setDescription("ID de l'utilisateur").setRequired(true)),

  new SlashCommandBuilder().setName("blcheck").setDescription("Voir la blacklist"),
  new SlashCommandBuilder().setName("banlist").setDescription("Voir la liste des bans actifs du serveur"),

  new SlashCommandBuilder()
    .setName("wl")
    .setDescription("Gérer la whitelist (bypass anti-link/anti-spam)")
    .addSubcommand(sub =>
      sub.setName("add")
        .setDescription("Ajouter un utilisateur à la whitelist")
        .addStringOption(o => o.setName("id").setDescription("ID de l'utilisateur").setRequired(true))
        .addStringOption(o => o.setName("tag").setDescription("Tag de l'utilisateur").setRequired(true))
    )
    .addSubcommand(sub =>
      sub.setName("remove")
        .setDescription("Retirer un utilisateur de la whitelist")
        .addStringOption(o => o.setName("id").setDescription("ID de l'utilisateur").setRequired(true))
    )
    .addSubcommand(sub => sub.setName("check").setDescription("Voir la whitelist")),

  new SlashCommandBuilder()
    .setName("backup")
    .setDescription("Gérer les sauvegardes du bot")
    .addSubcommand(sub => sub.setName("create").setDescription("Créer une sauvegarde"))
    .addSubcommand(sub => sub.setName("list").setDescription("Voir les sauvegardes disponibles"))
    .addSubcommand(sub =>
      sub.setName("load")
        .setDescription("Restaurer une sauvegarde")
        .addStringOption(o => o.setName("id").setDescription("ID de la sauvegarde").setRequired(true))
    ),

  new SlashCommandBuilder()
    .setName("maintenance")
    .setDescription("Activer/désactiver le mode maintenance")
    .addStringOption(o =>
      o.setName("statut").setDescription("on ou off").setRequired(true)
        .addChoices({ name: "Activer", value: "on" }, { name: "Désactiver", value: "off" })
    )
    .addStringOption(o => o.setName("message").setDescription("Message de maintenance personnalisé").setRequired(false)),

  // Perm 5 (Paix)
  new SlashCommandBuilder()
    .setName("owner")
    .setDescription("Gérer les owners du bot")
    .addSubcommand(sub =>
      sub.setName("add")
        .setDescription("Ajouter un owner")
        .addStringOption(o => o.setName("id").setDescription("ID de l'utilisateur").setRequired(true))
        .addStringOption(o => o.setName("tag").setDescription("Tag de l'utilisateur").setRequired(true))
    )
    .addSubcommand(sub =>
      sub.setName("remove")
        .setDescription("Retirer un owner")
        .addStringOption(o => o.setName("id").setDescription("ID de l'utilisateur").setRequired(true))
    )
    .addSubcommand(sub => sub.setName("list").setDescription("Voir la liste des owners")),

  new SlashCommandBuilder()
    .setName("antilink")
    .setDescription("Activer/désactiver le filtre de liens")
    .addStringOption(o =>
      o.setName("statut").setDescription("on ou off").setRequired(true)
        .addChoices({ name: "Activer", value: "on" }, { name: "Désactiver", value: "off" })
    ),

  new SlashCommandBuilder()
    .setName("antispam")
    .setDescription("Activer/désactiver l'anti-spam")
    .addStringOption(o =>
      o.setName("statut").setDescription("on ou off").setRequired(true)
        .addChoices({ name: "Activer", value: "on" }, { name: "Désactiver", value: "off" })
    )
    .addIntegerOption(o => o.setName("seuil").setDescription("Nombre de messages avant action (défaut: 5)").setRequired(false))
    .addIntegerOption(o => o.setName("intervalle").setDescription("Intervalle en secondes (défaut: 5)").setRequired(false)),

  new SlashCommandBuilder()
    .setName("antiraid")
    .setDescription("Activer/désactiver l'anti-raid")
    .addStringOption(o =>
      o.setName("statut").setDescription("on ou off").setRequired(true)
        .addChoices({ name: "Activer", value: "on" }, { name: "Désactiver", value: "off" })
    )
    .addIntegerOption(o => o.setName("seuil").setDescription("Rejoins en 10s avant lockdown (défaut: 5)").setRequired(false)),

  new SlashCommandBuilder()
    .setName("antiraid-reset")
    .setDescription("Désactiver le lockdown anti-raid actif"),
];

// ══════════════════════════════════════════════════════════════════════════════
// READY
// ══════════════════════════════════════════════════════════════════════════════
client.once(Events.ClientReady, async readyClient => {
  console.log(`✅ Bot connecté en tant que ${readyClient.user.tag}`);
  const rest = new REST().setToken(TOKEN!);
  for (const guild of readyClient.guilds.cache.values()) {
    await rest.put(Routes.applicationGuildCommands(readyClient.user.id, guild.id), {
      body: commands.map(c => c.toJSON()),
    });
  }
  console.log("✅ Commandes slash enregistrées.");
  console.log(`📌 Config: antilink=${getConfig().antilink} antispam=${getConfig().antispam} antiraid=${getConfig().antiraid} maintenance=${getConfig().maintenanceMode}`);
});

// ══════════════════════════════════════════════════════════════════════════════
// AUTO-BAN BLACKLISTED USERS ON JOIN + ANTI-RAID
// ══════════════════════════════════════════════════════════════════════════════
client.on(Events.GuildMemberAdd, async (member: GuildMember) => {
  if (isBlacklisted(member.id)) {
    await member.ban({ reason: "Utilisateur blacklisté — auto-ban" }).catch(() => null);
    console.log(`🚫 Auto-ban: ${member.user.tag} (${member.id}) blacklisté.`);
    return;
  }
  const raided = await handleAntiRaid(member);
  if (raided) console.log(`🛡️ Anti-raid: ${member.user.tag} banni.`);
});

// ══════════════════════════════════════════════════════════════════════════════
// ANTI-SPAM / ANTI-LINK ON MESSAGE
// ══════════════════════════════════════════════════════════════════════════════
client.on(Events.MessageCreate, async (message: Message) => {
  if (message.author.bot || !message.guild) return;
  const config = getConfig();
  if (config.maintenanceMode) return;

  // Anti-spam / anti-link
  await handleAntiSpam(message);
});

// ══════════════════════════════════════════════════════════════════════════════
// TICKET HELPERS
// ══════════════════════════════════════════════════════════════════════════════
async function hasTicketAccess(guild: Guild, userId: string): Promise<boolean> {
  const member = await guild.members.fetch(userId).catch(() => null);
  if (!member) return false;
  const accessRoleNames = ["Modérateurs", "+++", "admin", "paix", "Acces Ticket"];
  return accessRoleNames.some(roleName => {
    const role = guild.roles.cache.find(r => r.name === roleName);
    return role ? member.roles.cache.has(role.id) : false;
  });
}

async function canActOnTicket(guild: Guild, actorId: string, openerId: string): Promise<boolean> {
  const member = await guild.members.fetch(actorId).catch(() => null);
  if (!member) return false;
  const highRoles = ["Modérateurs", "+++", "admin", "paix"];
  if (highRoles.some(name => {
    const r = guild.roles.cache.find(r => r.name === name);
    return r ? member.roles.cache.has(r.id) : false;
  })) return true;
  const accessRole = guild.roles.cache.find(r => r.name === "Acces Ticket");
  if (accessRole && member.roles.cache.has(accessRole.id) && actorId !== openerId) return true;
  if (isOwner(actorId)) return true;
  return false;
}

async function closeTicket(channel: TextChannel, closedBy: string, reason: string): Promise<void> {
  await channel.send({
    embeds: [new EmbedBuilder()
      .setTitle("🔒 Ticket fermé")
      .setColor(COLOR.grey)
      .addFields({ name: "Fermé par", value: closedBy, inline: true }, { name: "Raison", value: reason, inline: true })
      .setTimestamp()],
  }).catch(() => null);
  setTimeout(() => channel.delete().catch(() => null), 5000);
}

// ══════════════════════════════════════════════════════════════════════════════
// INTERACTIONS
// ══════════════════════════════════════════════════════════════════════════════
client.on(Events.InteractionCreate, async (interaction: Interaction) => {
  try {

  const config = getConfig();
  if (config.maintenanceMode && !interaction.isButton()) {
    if (interaction.isChatInputCommand()) {
      const permLevel = await getPermLevel(interaction.guild!, interaction.user.id);
      if (permLevel < 4) {
        await interaction.reply({
          embeds: [new EmbedBuilder()
            .setColor(COLOR.yellow)
            .setTitle("🔧 Bot en maintenance")
            .setDescription(config.maintenanceMessage)
            .setTimestamp()],
          flags: MessageFlags.Ephemeral,
        });
        return;
      }
    }
  }

  // ════════════════════════════════════════════════════════════════════════════
  // BUTTONS
  // ════════════════════════════════════════════════════════════════════════════
  if (interaction.isButton()) {
    const { customId, guild } = interaction;

    if (customId === "cancel_confirm") {
      await interaction.update({
        embeds: [new EmbedBuilder().setColor(COLOR.grey).setDescription("❌ Action annulée.").setTimestamp()],
        components: [],
      });
      return;
    }

    // ── Navigation HELP (message permanent — update) ──────────────────────
    if (customId.startsWith("help_prev_") || customId.startsWith("help_next_")) {
      const pages = buildHelpPages();
      const currentPage = parseInt(customId.split("_").pop()!, 10);
      const newPage = customId.startsWith("help_next_") ? currentPage + 1 : currentPage - 1;
      const safePage = Math.max(0, Math.min(newPage, pages.length - 1));
      await interaction.update({
        embeds: [pages[safePage]!],
        components: [helpNavRow(safePage, pages.length)],
      });
      return;
    }

    // ── Accepter le règlement ────────────────────────────────────────────
    if (customId === "toggle_role_corbeaux") {
      if (!guild) { await interaction.reply({ embeds: [errEmbed("Non disponible ici.")], flags: MessageFlags.Ephemeral }); return; }
      const role = guild.roles.cache.get(ROLE_ID!);
      if (!role) { await interaction.reply({ embeds: [errEmbed("Rôle introuvable. Vérifiez ROLE_ID.")], flags: MessageFlags.Ephemeral }); return; }
      const member = await guild.members.fetch(interaction.user.id);
      if (member.roles.cache.has(role.id)) {
        await member.roles.remove(role);
        await interaction.reply({ embeds: [okEmbed("Rôle retiré", "Le rôle **Corbeaux+** t'a été retiré.")], flags: MessageFlags.Ephemeral });
      } else {
        await member.roles.add(role);
        await interaction.reply({ embeds: [okEmbed("Bienvenue ! 🦉", "Le rôle **Corbeaux+** t'a été attribué.")], flags: MessageFlags.Ephemeral });
      }
      return;
    }

    // ── Ticket déban ────────────────────────────────────────────────────
    if (customId === "open_ticket_deban") {
      const modal = new ModalBuilder().setCustomId("modal_ticket_deban").setTitle("📋 Demande de déban");
      modal.addComponents(
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder().setCustomId("pseudo_ban").setLabel("Ton pseudo sur le site").setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(100)
        ),
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder().setCustomId("mod_ban").setLabel("Qui t'a banni ? (pseudo ou 'inconnu')").setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(100)
        ),
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder().setCustomId("raison_ban").setLabel("Raison du ban indiquée").setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(200)
        ),
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder().setCustomId("justification").setLabel("Pourquoi mérites-tu un déban ?").setStyle(TextInputStyle.Paragraph).setRequired(true).setMaxLength(1000)
        ),
      );
      await interaction.showModal(modal);
      return;
    }

    if (customId === "open_ticket_proposition") {
      const modal = new ModalBuilder().setCustomId("modal_ticket_proposition").setTitle("📺 Proposition d'ajout de stream");
      modal.addComponents(
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder().setCustomId("nom_rencontre").setLabel("Nom de la rencontre et de la compétition").setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(150)
        ),
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder().setCustomId("heure").setLabel("Heure du coup d'envoi").setPlaceholder("Ex: 21h00").setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(20)
        ),
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder().setCustomId("chaine").setLabel("Chaîne de diffusion").setPlaceholder("Ex: Canal+, beIN Sports 1...").setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(100)
        ),
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder().setCustomId("sport").setLabel("Sport").setPlaceholder("Ex: Football, Basketball...").setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(50)
        ),
      );
      await interaction.showModal(modal);
      return;
    }

    if (customId.startsWith("ticket_accept_")) {
      if (!guild) return;
      const channelId = customId.replace("ticket_accept_", "");
      const openerId = debanTicketCache.get(channelId) ?? "";
      if (!(await canActOnTicket(guild, interaction.user.id, openerId))) {
        await interaction.reply({ embeds: [errEmbed(openerId === interaction.user.id ? "Tu ne peux pas accepter ton propre ticket." : "Permission insuffisante.")], flags: MessageFlags.Ephemeral });
        return;
      }
      await interaction.reply({
        embeds: [infoEmbed("⚠️ Confirmation", "Veux-tu vraiment **accepter** cette demande de déban ?")],
        components: [confirmRow(`confirm_deban_accept_${channelId}`, "✅ Oui, accepter")],
        flags: MessageFlags.Ephemeral,
      });
      return;
    }

    if (customId.startsWith("ticket_refuse_")) {
      if (!guild) return;
      const channelId = customId.replace("ticket_refuse_", "");
      const openerId = debanTicketCache.get(channelId) ?? "";
      if (!(await canActOnTicket(guild, interaction.user.id, openerId))) {
        await interaction.reply({ embeds: [errEmbed(openerId === interaction.user.id ? "Tu ne peux pas refuser ton propre ticket." : "Permission insuffisante.")], flags: MessageFlags.Ephemeral });
        return;
      }
      await interaction.reply({
        embeds: [infoEmbed("⚠️ Confirmation", "Veux-tu vraiment **refuser** cette demande de déban ?")],
        components: [confirmRow(`confirm_deban_refuse_${channelId}`, "❌ Oui, refuser")],
        flags: MessageFlags.Ephemeral,
      });
      return;
    }

    if (customId.startsWith("ticket_close_")) {
      if (!guild) return;
      const channelId = customId.replace("ticket_close_", "");
      const openerId = debanTicketCache.get(channelId) ?? propositionCache.get(channelId)?.userId ?? "";
      if (!(await canActOnTicket(guild, interaction.user.id, openerId))) {
        await interaction.reply({ embeds: [errEmbed("Seul le staff peut fermer ce ticket.")], flags: MessageFlags.Ephemeral });
        return;
      }
      await interaction.reply({
        embeds: [infoEmbed("⚠️ Confirmation", "Veux-tu vraiment **fermer** ce ticket ? Le salon sera supprimé dans 5s.")],
        components: [confirmRow(`confirm_close_${channelId}`, "🔒 Oui, fermer")],
        flags: MessageFlags.Ephemeral,
      });
      return;
    }

    if (customId.startsWith("confirm_deban_accept_")) {
      if (!guild) return;
      const channel = interaction.channel as TextChannel;
      const channelId = customId.replace("confirm_deban_accept_", "");
      await channel.send({
        embeds: [new EmbedBuilder().setColor(COLOR.green).setTitle("✅ Demande acceptée")
          .setDescription("La demande de déban a été **acceptée**. Un modérateur procédera au déban manuellement.")
          .addFields({ name: "Accepté par", value: interaction.user.tag }).setTimestamp()],
      });
      await interaction.update({ embeds: [successEmbed("Demande acceptée. Le ticket va se fermer.")], components: [] });
      await sendLog(guild, "⚙️・logs•tickets•demande-deban", new EmbedBuilder().setColor(COLOR.green)
        .setTitle("✅ Déban — Accepté").addFields(
          { name: "Ticket", value: channel.name, inline: true },
          { name: "Par", value: interaction.user.tag, inline: true },
        ).setTimestamp());
      debanTicketCache.delete(channelId);
      await closeTicket(channel, interaction.user.tag, "Demande acceptée");
      return;
    }

    if (customId.startsWith("confirm_deban_refuse_")) {
      if (!guild) return;
      const channel = interaction.channel as TextChannel;
      const channelId = customId.replace("confirm_deban_refuse_", "");
      await channel.send({
        embeds: [new EmbedBuilder().setColor(COLOR.red).setTitle("❌ Demande refusée")
          .setDescription("Ta demande de déban a été **refusée** par la modération.")
          .addFields({ name: "Refusé par", value: interaction.user.tag }).setTimestamp()],
      });
      await interaction.update({ embeds: [errEmbed("Demande refusée. Le ticket va se fermer.")], components: [] });
      await sendLog(guild, "⚙️・logs•tickets•demande-deban", new EmbedBuilder().setColor(COLOR.red)
        .setTitle("❌ Déban — Refusé").addFields(
          { name: "Ticket", value: channel.name, inline: true },
          { name: "Par", value: interaction.user.tag, inline: true },
        ).setTimestamp());
      debanTicketCache.delete(channelId);
      await closeTicket(channel, interaction.user.tag, "Demande refusée");
      return;
    }

    if (customId.startsWith("confirm_close_")) {
      if (!guild) return;
      const channelId = customId.replace("confirm_close_", "");
      const channel = interaction.channel as TextChannel;
      await interaction.update({ embeds: [successEmbed("Ticket fermé.")], components: [] });
      debanTicketCache.delete(channelId);
      propositionCache.delete(channelId);
      await closeTicket(channel, interaction.user.tag, "Ticket fermé manuellement");
      return;
    }

    if (customId.startsWith("prop_accept_")) {
      if (!guild) return;
      const channelId = customId.replace("prop_accept_", "");
      if (!(await hasTicketAccess(guild, interaction.user.id))) {
        await interaction.reply({ embeds: [errEmbed("Permission insuffisante.")], flags: MessageFlags.Ephemeral });
        return;
      }
      const data = propositionCache.get(channelId);
      const channel = interaction.channel as TextChannel;
      const validChannel = guild.channels.cache.find(c => c.name === "✅・suggestions•validé" && c instanceof TextChannel);
      if (validChannel instanceof TextChannel && data) {
        await validChannel.send({
          embeds: [new EmbedBuilder().setColor(COLOR.green).setTitle("✅ Proposition acceptée")
            .addFields(
              { name: "Rencontre", value: data.nomRencontre, inline: true },
              { name: "Heure", value: data.heure, inline: true },
              { name: "Chaîne", value: data.chaine, inline: true },
              { name: "Sport", value: data.sport, inline: true },
              { name: "Proposé par", value: `${data.userTag}`, inline: true },
              { name: "Accepté par", value: interaction.user.tag, inline: true },
            ).setTimestamp()],
        });
      }
      await interaction.update({ embeds: [successEmbed("Proposition acceptée.")], components: [] });
      await sendLog(guild, "⚙️・logs・proposition・stream", new EmbedBuilder().setColor(COLOR.green)
        .setTitle("✅ Proposition acceptée").addFields(
          { name: "Par", value: interaction.user.tag, inline: true },
          { name: "Rencontre", value: data?.nomRencontre ?? "—", inline: true },
        ).setTimestamp());
      propositionCache.delete(channelId);
      await closeTicket(channel, interaction.user.tag, "Proposition acceptée");
      return;
    }

    if (customId.startsWith("prop_refuse_")) {
      if (!guild) return;
      const channelId = customId.replace("prop_refuse_", "");
      if (!(await hasTicketAccess(guild, interaction.user.id))) {
        await interaction.reply({ embeds: [errEmbed("Permission insuffisante.")], flags: MessageFlags.Ephemeral });
        return;
      }
      await interaction.reply({
        embeds: [infoEmbed("⚠️ Confirmation", "Veux-tu vraiment **refuser** cette proposition ?")],
        components: [confirmRow(`confirm_prop_refuse_${channelId}`, "❌ Oui, refuser")],
        flags: MessageFlags.Ephemeral,
      });
      return;
    }

    if (customId.startsWith("confirm_prop_refuse_")) {
      if (!guild) return;
      const channelId = customId.replace("confirm_prop_refuse_", "");
      const channel = interaction.channel as TextChannel;
      await channel.send({
        embeds: [new EmbedBuilder().setColor(COLOR.red).setTitle("❌ Proposition refusée")
          .addFields({ name: "Refusé par", value: interaction.user.tag }).setTimestamp()],
      });
      await interaction.update({ embeds: [errEmbed("Proposition refusée.")], components: [] });
      await sendLog(guild, "⚙️・logs・proposition・stream", new EmbedBuilder().setColor(COLOR.red)
        .setTitle("❌ Proposition refusée").addFields(
          { name: "Par", value: interaction.user.tag, inline: true },
        ).setTimestamp());
      propositionCache.delete(channelId);
      await closeTicket(channel, interaction.user.tag, "Proposition refusée");
      return;
    }

    return;
  }

  // ════════════════════════════════════════════════════════════════════════════
  // MODALS
  // ════════════════════════════════════════════════════════════════════════════
  if (interaction.isModalSubmit()) {
    const { customId, guild } = interaction;
    if (!guild) return;

    if (customId === "modal_ticket_deban") {
      const pseudoBan = interaction.fields.getTextInputValue("pseudo_ban");
      const modBan = interaction.fields.getTextInputValue("mod_ban");
      const raisonBan = interaction.fields.getTextInputValue("raison_ban");
      const justification = interaction.fields.getTextInputValue("justification");

      const cat = guild.channels.cache.find(c => c.name.toLowerCase().includes("déban") && c.type === ChannelType.GuildCategory);
      const ticket = await guild.channels.create({
        name: `deban-${interaction.user.username}`,
        type: ChannelType.GuildText,
        parent: cat?.id,
        permissionOverwrites: [
          { id: guild.roles.everyone, deny: [PermissionFlagsBits.ViewChannel] },
          { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] },
        ],
      });

      for (const roleName of ["Modérateurs", "+++", "admin", "paix", "Acces Ticket"]) {
        const role = guild.roles.cache.find(r => r.name === roleName);
        if (role) await ticket.permissionOverwrites.create(role, { ViewChannel: true, SendMessages: true }).catch(() => null);
      }

      debanTicketCache.set(ticket.id, interaction.user.id);

      const embed = new EmbedBuilder()
        .setColor(COLOR.blue).setTitle("📋 Demande de déban")
        .setThumbnail(interaction.user.displayAvatarURL())
        .addFields(
          { name: "Demandeur", value: `${interaction.user.tag} (${interaction.user.id})`, inline: false },
          { name: "Pseudo banni", value: pseudoBan, inline: true },
          { name: "Modérateur ayant banni", value: modBan, inline: true },
          { name: "Raison du ban", value: raisonBan, inline: false },
          { name: "Justification", value: justification, inline: false },
        ).setTimestamp();

      const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder().setCustomId(`ticket_accept_${ticket.id}`).setLabel("✅ Accepter").setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId(`ticket_refuse_${ticket.id}`).setLabel("❌ Refuser").setStyle(ButtonStyle.Danger),
        new ButtonBuilder().setCustomId(`ticket_close_${ticket.id}`).setLabel("🔒 Fermer").setStyle(ButtonStyle.Secondary),
      );

      await ticket.send({ embeds: [embed], components: [row] });
      await sendLog(guild, "⚙️・logs•tickets•demande-deban", new EmbedBuilder().setColor(COLOR.blue)
        .setTitle("📋 Nouveau ticket déban").addFields(
          { name: "Demandeur", value: interaction.user.tag, inline: true },
          { name: "Salon", value: ticket.name, inline: true },
        ).setTimestamp());
      await interaction.reply({ embeds: [okEmbed("Ticket créé !", `Ta demande a été créée dans ${ticket}. Le staff va traiter ta demande.`)], flags: MessageFlags.Ephemeral });
      return;
    }

    if (customId === "modal_ticket_proposition") {
      const nomRencontre = interaction.fields.getTextInputValue("nom_rencontre");
      const heure = interaction.fields.getTextInputValue("heure");
      const chaine = interaction.fields.getTextInputValue("chaine");
      const sport = interaction.fields.getTextInputValue("sport");

      const cat = guild.channels.cache.find(c => c.name.toLowerCase().includes("proposition") && c.type === ChannelType.GuildCategory);
      const ticket = await guild.channels.create({
        name: `prop-${interaction.user.username}`,
        type: ChannelType.GuildText,
        parent: cat?.id,
        permissionOverwrites: [
          { id: guild.roles.everyone, deny: [PermissionFlagsBits.ViewChannel] },
          { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] },
        ],
      });

      for (const roleName of ["Modérateurs", "+++", "admin", "paix", "Acces Ticket"]) {
        const role = guild.roles.cache.find(r => r.name === roleName);
        if (role) await ticket.permissionOverwrites.create(role, { ViewChannel: true, SendMessages: true }).catch(() => null);
      }

      propositionCache.set(ticket.id, {
        nomRencontre, heure, chaine, sport,
        userId: interaction.user.id,
        userTag: interaction.user.tag,
        userAvatar: interaction.user.displayAvatarURL(),
      });

      const embed = new EmbedBuilder()
        .setColor(COLOR.purple).setTitle("📺 Proposition de stream")
        .setThumbnail(interaction.user.displayAvatarURL())
        .addFields(
          { name: "Proposé par", value: `${interaction.user.tag} (${interaction.user.id})`, inline: false },
          { name: "🏆 Rencontre", value: nomRencontre, inline: true },
          { name: "⏰ Heure", value: heure, inline: true },
          { name: "📺 Chaîne", value: chaine, inline: true },
          { name: "⚽ Sport", value: sport, inline: true },
        ).setTimestamp();

      const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder().setCustomId(`prop_accept_${ticket.id}`).setLabel("✅ Accepter").setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId(`prop_refuse_${ticket.id}`).setLabel("❌ Refuser").setStyle(ButtonStyle.Danger),
        new ButtonBuilder().setCustomId(`ticket_close_${ticket.id}`).setLabel("🔒 Fermer").setStyle(ButtonStyle.Secondary),
      );

      await ticket.send({ embeds: [embed], components: [row] });
      await sendLog(guild, "⚙️・logs・proposition・stream", new EmbedBuilder().setColor(COLOR.purple)
        .setTitle("📺 Nouvelle proposition").addFields(
          { name: "Proposé par", value: interaction.user.tag, inline: true },
          { name: "Rencontre", value: nomRencontre, inline: true },
        ).setTimestamp());
      await interaction.reply({ embeds: [okEmbed("Proposition envoyée !", `Ta proposition a été créée dans ${ticket}.`)], flags: MessageFlags.Ephemeral });
      return;
    }

    return;
  }

  // ════════════════════════════════════════════════════════════════════════════
  // SLASH COMMANDS
  // ════════════════════════════════════════════════════════════════════════════
  if (!interaction.isChatInputCommand()) return;
  const { commandName, guild } = interaction;
  if (!guild) return;

  // ── /help — Message permanent avec navigation ─────────────────────────────
  if (commandName === "help") {
    const pages = buildHelpPages();
    // Confirmer à l'utilisateur avec un message éphémère
    await interaction.reply({
      embeds: [new EmbedBuilder().setColor(COLOR.green).setDescription("✅ Menu d'aide posté !")],
      flags: MessageFlags.Ephemeral,
    });
    // Poster le vrai message permanent dans le salon
    await interaction.channel!.send({
      embeds: [pages[0]!],
      components: [helpNavRow(0, pages.length)],
    });
    return;
  }

  // ── /perm ─────────────────────────────────────────────────────────────────
  if (commandName === "perm") {
    const embed = new EmbedBuilder()
      .setColor(COLOR.blue)
      .setTitle("🔑 Niveaux de permission — Hiboux Bot")
      .setDescription("Voici les différents niveaux de permission du bot :")
      .addFields(
        { name: "⚫ Perm 5 — @paix", value: "Owner du bot. Accès total à toutes les commandes.", inline: false },
        { name: "🔴 Perm 4 — @admin", value: "Administration complète (bl, règles, tickets, antilink, backup, maintenance, lock, unlock, renew…).", inline: false },
        { name: "🟡 Perm 3 — @+++ (Chef Modo)", value: "Chef modérateur. Clear, rank, rank-top.", inline: false },
        { name: "🔵 Perm 2 — @++ (Modérateur)", value: "Kick, ban, unban.", inline: false },
        { name: "🟢 Perm 1 — @+ (Helpeur)", value: "Warn, unwarn, warnlist, mute, unmute.", inline: false },
        { name: "⬜ Perm 0", value: "Tout le monde — /help, /perm, /rank (soi-même).", inline: false },
      )
      .setFooter({ text: "Corbeaux Bot v2.0 • Système de permissions" })
      .setTimestamp();
    await interaction.reply({ embeds: [embed] });
    return;
  }

  const permLevel = await getPermLevel(guild, interaction.user.id);
  const noPerm = errEmbed("Tu n'as pas la permission d'utiliser cette commande.");

  // ── /warn ─────────────────────────────────────────────────────────────────
  if (commandName === "warn") {
    if (permLevel < 1) { await interaction.reply({ embeds: [noPerm], flags: MessageFlags.Ephemeral }); return; }
    const target = interaction.options.getUser("membre", true);
    const raison = interaction.options.getString("raison") ?? "Aucune raison fournie";
    const id = generateWarnId();
    addWarning({ id, userId: target.id, userTag: target.tag, raison, warnedAt: new Date().toISOString(), warnedBy: interaction.user.tag, warnedById: interaction.user.id });
    const warns = getWarnings(target.id);
    const logEmbed = new EmbedBuilder().setColor(COLOR.yellow).setTitle("⚠️ Avertissement donné")
      .addFields(
        { name: "Utilisateur", value: `${target.tag} (${target.id})`, inline: true },
        { name: "Modérateur", value: interaction.user.tag, inline: true },
        { name: "Raison", value: raison, inline: false },
        { name: "Total warns", value: `${warns.length}`, inline: true },
        { name: "ID du warn", value: `\`${id}\``, inline: true },
      ).setTimestamp();
    await interaction.reply({ embeds: [successEmbed(`Avertissement donné à **${target.tag}** (total : ${warns.length}).`)] });
    await sendLog(guild, "⚙️・logs•mute•unmute", logEmbed);
    return;
  }

  // ── /unwarn ───────────────────────────────────────────────────────────────
  if (commandName === "unwarn") {
    if (permLevel < 1) { await interaction.reply({ embeds: [noPerm], flags: MessageFlags.Ephemeral }); return; }
    const target = interaction.options.getUser("membre", true);
    const warnId = interaction.options.getString("id");
    if (warnId) {
      const removed = removeWarning(warnId);
      if (!removed) { await interaction.reply({ embeds: [errEmbed(`Warn \`${warnId}\` introuvable.`)], flags: MessageFlags.Ephemeral }); return; }
      const logEmbed = new EmbedBuilder().setColor(COLOR.green).setTitle("✅ Warn retiré")
        .addFields(
          { name: "Utilisateur", value: `${target.tag} (${target.id})`, inline: true },
          { name: "Modérateur", value: interaction.user.tag, inline: true },
          { name: "ID warn", value: `\`${warnId}\``, inline: true },
        ).setTimestamp();
      await interaction.reply({ embeds: [successEmbed(`Warn \`${warnId}\` supprimé.`)] });
      await sendLog(guild, "⚙️・logs•mute•unmute", logEmbed);
    } else {
      const count = clearWarnings(target.id);
      const logEmbed = new EmbedBuilder().setColor(COLOR.green).setTitle("✅ Tous les warns supprimés")
        .addFields(
          { name: "Utilisateur", value: `${target.tag} (${target.id})`, inline: true },
          { name: "Modérateur", value: interaction.user.tag, inline: true },
          { name: "Nombre supprimés", value: `${count}`, inline: true },
        ).setTimestamp();
      await interaction.reply({ embeds: [successEmbed(`${count} avertissement(s) supprimé(s) pour **${target.tag}**.`)] });
      await sendLog(guild, "⚙️・logs•mute•unmute", logEmbed);
    }
    return;
  }

  // ── /warnlist ─────────────────────────────────────────────────────────────
  if (commandName === "warnlist") {
    if (permLevel < 1) { await interaction.reply({ embeds: [noPerm], flags: MessageFlags.Ephemeral }); return; }
    const target = interaction.options.getUser("membre", true);
    const warns = getWarnings(target.id);
    if (warns.length === 0) {
      await interaction.reply({ embeds: [okEmbed("⚠️ Warns", `**${target.tag}** n'a aucun avertissement.`)], flags: MessageFlags.Ephemeral });
      return;
    }
    const embed = new EmbedBuilder().setColor(COLOR.yellow).setTitle(`⚠️ Warns de ${target.tag}`)
      .setDescription(warns.map((w, i) =>
        `**${i + 1}.** ID: \`${w.id}\`\n> Raison : ${w.raison}\n> Par : ${w.warnedBy} — ${new Date(w.warnedAt).toLocaleDateString("fr-FR")}`
      ).join("\n\n"))
      .setFooter({ text: `${warns.length} avertissement(s)` }).setTimestamp();
    await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
    return;
  }

  // ── /mute ─────────────────────────────────────────────────────────────────
  if (commandName === "mute") {
    if (permLevel < 1) { await interaction.reply({ embeds: [noPerm], flags: MessageFlags.Ephemeral }); return; }
    const target = interaction.options.getUser("membre", true);
    const dureeRaw = interaction.options.getString("duree", true);
    const unite = interaction.options.getString("unite", true);
    const raison = interaction.options.getString("raison") ?? "Aucune raison fournie";
    const valeur = parseInt(dureeRaw, 10);
    if (isNaN(valeur) || valeur < 1) { await interaction.reply({ embeds: [errEmbed("La durée doit être un nombre entier positif.")], flags: MessageFlags.Ephemeral }); return; }
    const msMap: Record<string, number> = { secondes: 1000, minutes: 60000, heures: 3600000, jours: 86400000 };
    const totalMs = valeur * (msMap[unite] ?? 1000);
    if (totalMs > 28 * 24 * 3600000) { await interaction.reply({ embeds: [errEmbed("La durée maximale est de **28 jours**.")], flags: MessageFlags.Ephemeral }); return; }
    const member = await guild.members.fetch(target.id).catch(() => null);
    if (!member) { await interaction.reply({ embeds: [errEmbed("Membre introuvable.")], flags: MessageFlags.Ephemeral }); return; }
    if (!member.moderatable) { await interaction.reply({ embeds: [errEmbed("Je ne peux pas muter ce membre.")], flags: MessageFlags.Ephemeral }); return; }
    await member.timeout(totalMs, raison);
    const logEmbed = new EmbedBuilder().setColor(COLOR.orange).setTitle("🔇 Membre muté")
      .addFields(
        { name: "Utilisateur", value: `${target.tag} (${target.id})`, inline: true },
        { name: "Modérateur", value: interaction.user.tag, inline: true },
        { name: "Durée", value: `${valeur} ${unite}`, inline: true },
        { name: "Raison", value: raison },
      ).setTimestamp();
    await interaction.reply({ embeds: [successEmbed()] });
    await sendLog(guild, "⚙️・logs•mute•unmute", logEmbed);
    return;
  }

  // ── /unmute ───────────────────────────────────────────────────────────────
  if (commandName === "unmute") {
    if (permLevel < 1) { await interaction.reply({ embeds: [noPerm], flags: MessageFlags.Ephemeral }); return; }
    const target = interaction.options.getUser("membre", true);
    const member = await guild.members.fetch(target.id).catch(() => null);
    if (!member) { await interaction.reply({ embeds: [errEmbed("Membre introuvable.")], flags: MessageFlags.Ephemeral }); return; }
    await member.timeout(null);
    const logEmbed = new EmbedBuilder().setColor(COLOR.green).setTitle("🔊 Membre démuté")
      .addFields(
        { name: "Utilisateur", value: `${target.tag} (${target.id})`, inline: true },
        { name: "Modérateur", value: interaction.user.tag, inline: true },
      ).setTimestamp();
    await interaction.reply({ embeds: [successEmbed()] });
    await sendLog(guild, "⚙️・logs•mute•unmute", logEmbed);
    return;
  }

  // ── /kick ─────────────────────────────────────────────────────────────────
  if (commandName === "kick") {
    if (permLevel < 2) { await interaction.reply({ embeds: [noPerm], flags: MessageFlags.Ephemeral }); return; }
    const target = interaction.options.getUser("membre", true);
    const raison = interaction.options.getString("raison") ?? "Aucune raison fournie";
    const member = await guild.members.fetch(target.id).catch(() => null);
    if (!member) { await interaction.reply({ embeds: [errEmbed("Membre introuvable.")], flags: MessageFlags.Ephemeral }); return; }
    if (!member.kickable) { await interaction.reply({ embeds: [errEmbed("Je ne peux pas expulser ce membre.")], flags: MessageFlags.Ephemeral }); return; }
    await member.kick(raison);
    const logEmbed = new EmbedBuilder().setColor(COLOR.orange).setTitle("👢 Membre expulsé")
      .addFields(
        { name: "Utilisateur", value: `${target.tag} (${target.id})`, inline: true },
        { name: "Modérateur", value: interaction.user.tag, inline: true },
        { name: "Raison", value: raison },
      ).setTimestamp();
    await interaction.reply({ embeds: [successEmbed()] });
    await sendLog(guild, "⚙️・logs", logEmbed);
    return;
  }

  // ── /ban ──────────────────────────────────────────────────────────────────
  if (commandName === "ban") {
    if (permLevel < 2) { await interaction.reply({ embeds: [noPerm], flags: MessageFlags.Ephemeral }); return; }
    const target = interaction.options.getUser("membre", true);
    const raison = interaction.options.getString("raison") ?? "Aucune raison fournie";
    const member = await guild.members.fetch(target.id).catch(() => null);
    if (!member) { await interaction.reply({ embeds: [errEmbed("Membre introuvable.")], flags: MessageFlags.Ephemeral }); return; }
    if (!member.bannable) { await interaction.reply({ embeds: [errEmbed("Je ne peux pas bannir ce membre.")], flags: MessageFlags.Ephemeral }); return; }
    await member.ban({ reason: raison });
    const logEmbed = new EmbedBuilder().setColor(COLOR.red).setTitle("🔨 Membre banni")
      .addFields(
        { name: "Utilisateur", value: `${target.tag} (${target.id})`, inline: true },
        { name: "Modérateur", value: interaction.user.tag, inline: true },
        { name: "Raison", value: raison },
      ).setTimestamp();
    await interaction.reply({ embeds: [successEmbed()] });
    await sendLog(guild, "⚙️・logs", logEmbed);
    return;
  }

  // ── /unban ────────────────────────────────────────────────────────────────
  if (commandName === "unban") {
    if (permLevel < 2) { await interaction.reply({ embeds: [noPerm], flags: MessageFlags.Ephemeral }); return; }
    const id = interaction.options.getString("id", true);
    const raison = interaction.options.getString("raison") ?? "Aucune raison fournie";
    const ban = await guild.bans.fetch(id).catch(() => null);
    if (!ban) { await interaction.reply({ embeds: [errEmbed("Aucun ban trouvé avec cet ID.")], flags: MessageFlags.Ephemeral }); return; }
    await guild.bans.remove(id, raison);
    const logEmbed = new EmbedBuilder().setColor(COLOR.green).setTitle("✅ Membre débanni")
      .addFields(
        { name: "ID", value: `\`${id}\``, inline: true },
        { name: "Modérateur", value: interaction.user.tag, inline: true },
        { name: "Raison", value: raison },
      ).setTimestamp();
    await interaction.reply({ embeds: [successEmbed()] });
    await sendLog(guild, "⚙️・logs", logEmbed);
    return;
  }

  // ── /clear — Perm 3 (Chef Modo) ───────────────────────────────────────────
  if (commandName === "clear") {
    if (permLevel < 3) { await interaction.reply({ embeds: [noPerm], flags: MessageFlags.Ephemeral }); return; }
    const nombre = interaction.options.getInteger("nombre", true);
    const targetUser = interaction.options.getUser("membre");
    const channel = interaction.channel as TextChannel;
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });
    let messages = await channel.messages.fetch({ limit: Math.min(nombre + 1, 100) });
    if (targetUser) messages = messages.filter(m => m.author.id === targetUser.id);
    const toDelete = [...messages.values()].slice(0, nombre);
    const deleted = await channel.bulkDelete(toDelete, true).catch(() => new Collection());
    await interaction.editReply({ embeds: [successEmbed(`${deleted.size} message(s) supprimé(s).`)] });
    await sendLog(guild, "⚙️・logs", new EmbedBuilder().setColor(COLOR.grey)
      .setTitle("🗑️ Clear — Messages supprimés")
      .addFields(
        { name: "Salon", value: channel.name, inline: true },
        { name: "Messages supprimés", value: `${deleted.size}`, inline: true },
        { name: "Par", value: interaction.user.tag, inline: true },
        { name: "Filtre membre", value: targetUser ? targetUser.tag : "Aucun", inline: true },
      ).setTimestamp());
    return;
  }

  // ── /lock — Perm 4 (Admin) ────────────────────────────────────────────────
  if (commandName === "lock") {
    if (permLevel < 4) { await interaction.reply({ embeds: [noPerm], flags: MessageFlags.Ephemeral }); return; }
    const targetChannel = (interaction.options.getChannel("salon") ?? interaction.channel) as TextChannel;
    const raison = interaction.options.getString("raison") ?? "Aucune raison fournie";
    await targetChannel.permissionOverwrites.edit(guild.roles.everyone, { SendMessages: false });
    await interaction.reply({ embeds: [okEmbed("🔒 Salon verrouillé", `Le salon ${targetChannel} a été verrouillé.\n**Raison :** ${raison}`)] });
    await sendLog(guild, "⚙️・logs", new EmbedBuilder().setColor(COLOR.red)
      .setTitle("🔒 Lock — Salon verrouillé")
      .addFields(
        { name: "Salon", value: targetChannel.name, inline: true },
        { name: "Par", value: interaction.user.tag, inline: true },
        { name: "Raison", value: raison },
      ).setTimestamp());
    return;
  }

  // ── /unlock — Perm 4 (Admin) ──────────────────────────────────────────────
  if (commandName === "unlock") {
    if (permLevel < 4) { await interaction.reply({ embeds: [noPerm], flags: MessageFlags.Ephemeral }); return; }
    const targetChannel = (interaction.options.getChannel("salon") ?? interaction.channel) as TextChannel;
    await targetChannel.permissionOverwrites.edit(guild.roles.everyone, { SendMessages: null });
    await interaction.reply({ embeds: [okEmbed("🔓 Salon déverrouillé", `Le salon ${targetChannel} a été déverrouillé.`)] });
    await sendLog(guild, "⚙️・logs", new EmbedBuilder().setColor(COLOR.green)
      .setTitle("🔓 Unlock — Salon déverrouillé")
      .addFields(
        { name: "Salon", value: targetChannel.name, inline: true },
        { name: "Par", value: interaction.user.tag, inline: true },
      ).setTimestamp());
    return;
  }

  // ── /renew — Perm 4 (Admin) ───────────────────────────────────────────────
  if (commandName === "renew") {
    if (permLevel < 4) { await interaction.reply({ embeds: [noPerm], flags: MessageFlags.Ephemeral }); return; }
    const raison = interaction.options.getString("raison") ?? "Aucune raison fournie";
    const channel = interaction.channel as TextChannel;
    const position = channel.position;
    const parent = channel.parentId;
    const name = channel.name;
    const topic = channel.topic;
    const nsfw = channel.nsfw;
    const perms = channel.permissionOverwrites.cache;

    await interaction.reply({ embeds: [infoEmbed("♻️ Renouvellement", "Ce salon va être recréé dans 3 secondes...")], flags: MessageFlags.Ephemeral });

    setTimeout(async () => {
      const newChannel = await guild.channels.create({
        name, type: ChannelType.GuildText, parent: parent ?? undefined,
        topic: topic ?? undefined, nsfw, position,
        permissionOverwrites: perms.map(p => ({ id: p.id, allow: p.allow, deny: p.deny })),
      });
      await channel.delete(`Renew par ${interaction.user.tag} : ${raison}`).catch(() => null);
      await (newChannel as TextChannel).send({
        embeds: [new EmbedBuilder().setColor(COLOR.blue).setTitle("♻️ Salon renouvelé")
          .setDescription(`Ce salon a été renouvelé par ${interaction.user.tag}.\n**Raison :** ${raison}`)
          .setTimestamp()],
      });
      await sendLog(guild, "⚙️・logs", new EmbedBuilder().setColor(COLOR.blue)
        .setTitle("♻️ Renew — Salon renouvelé")
        .addFields(
          { name: "Salon", value: name, inline: true },
          { name: "Par", value: interaction.user.tag, inline: true },
          { name: "Raison", value: raison },
        ).setTimestamp());
    }, 3000);
    return;
  }

  // ── /bl — Perm 4 ─────────────────────────────────────────────────────────
  if (commandName === "bl") {
    if (permLevel < 4) { await interaction.reply({ embeds: [noPerm], flags: MessageFlags.Ephemeral }); return; }
    const target = interaction.options.getUser("membre", true);
    const raison = interaction.options.getString("raison") ?? "Aucune raison fournie";
    addToBlacklist({ id: target.id, tag: target.tag, raison, addedAt: new Date().toISOString(), addedBy: interaction.user.tag });
    const member = await guild.members.fetch(target.id).catch(() => null);
    if (member) await member.ban({ reason: `Blacklist: ${raison}` }).catch(() => null);
    await interaction.reply({ embeds: [successEmbed(`**${target.tag}** a été blacklisté et banni.`)] });
    await sendLog(guild, "⚙️・logs•bl", new EmbedBuilder().setColor(COLOR.darkred)
      .setTitle("🚫 Blacklist — Ajout")
      .addFields(
        { name: "Utilisateur", value: `${target.tag} (${target.id})`, inline: true },
        { name: "Par", value: interaction.user.tag, inline: true },
        { name: "Raison", value: raison },
      ).setTimestamp());
    return;
  }

  // ── /unbl — Perm 4 ────────────────────────────────────────────────────────
  if (commandName === "unbl") {
    if (permLevel < 4) { await interaction.reply({ embeds: [noPerm], flags: MessageFlags.Ephemeral }); return; }
    const id = interaction.options.getString("id", true);
    const removed = removeFromBlacklist(id);
    if (!removed) { await interaction.reply({ embeds: [errEmbed(`Aucune entrée trouvée pour l'ID \`${id}\`.`)], flags: MessageFlags.Ephemeral }); return; }
    await interaction.reply({ embeds: [successEmbed(`ID \`${id}\` retiré de la blacklist.`)] });
    await sendLog(guild, "⚙️・logs•bl", new EmbedBuilder().setColor(COLOR.green)
      .setTitle("✅ Blacklist — Retrait")
      .addFields(
        { name: "ID retiré", value: `\`${id}\``, inline: true },
        { name: "Par", value: interaction.user.tag, inline: true },
      ).setTimestamp());
    return;
  }

  // ── /blcheck — Perm 4 ─────────────────────────────────────────────────────
  if (commandName === "blcheck") {
    if (permLevel < 4) { await interaction.reply({ embeds: [noPerm], flags: MessageFlags.Ephemeral }); return; }
    const list = getBlacklist();
    if (list.length === 0) { await interaction.reply({ embeds: [okEmbed("🚫 Blacklist", "La blacklist est vide.")], flags: MessageFlags.Ephemeral }); return; }
    const desc = list.map((e, i) => `**${i + 1}.** ${e.tag} (\`${e.id}\`)\n> ${e.raison} — par ${e.addedBy}`).join("\n\n");
    await interaction.reply({ embeds: [new EmbedBuilder().setColor(COLOR.darkred).setTitle(`🚫 Blacklist (${list.length})`).setDescription(desc).setTimestamp()], flags: MessageFlags.Ephemeral });
    return;
  }

  // ── /banlist — Perm 4 ─────────────────────────────────────────────────────
  if (commandName === "banlist") {
    if (permLevel < 4) { await interaction.reply({ embeds: [noPerm], flags: MessageFlags.Ephemeral }); return; }
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });
    const bans = await guild.bans.fetch().catch(() => new Collection());
    if (bans.size === 0) { await interaction.editReply({ embeds: [okEmbed("🔨 Bans", "Aucun ban actif.")] }); return; }
    const desc = [...bans.values()].slice(0, 20).map((b, i) => `**${i + 1}.** ${b.user.tag} (\`${b.user.id}\`)\n> ${b.reason ?? "Aucune raison"}`).join("\n\n");
    await interaction.editReply({ embeds: [new EmbedBuilder().setColor(COLOR.red).setTitle(`🔨 Bans actifs (${bans.size})`).setDescription(desc).setFooter({ text: "Affichage limité à 20" }).setTimestamp()] });
    return;
  }

  // ── /wl — Perm 4 ─────────────────────────────────────────────────────────
  if (commandName === "wl") {
    if (permLevel < 4) { await interaction.reply({ embeds: [noPerm], flags: MessageFlags.Ephemeral }); return; }
    const sub = interaction.options.getSubcommand();
    if (sub === "add") {
      const id = interaction.options.getString("id", true);
      const tag = interaction.options.getString("tag", true);
      addToWhitelist({ id, tag, addedAt: new Date().toISOString(), addedBy: interaction.user.tag });
      await interaction.reply({ embeds: [successEmbed(`**${tag}** ajouté à la whitelist.`)] });
    } else if (sub === "remove") {
      const id = interaction.options.getString("id", true);
      const removed = removeFromWhitelist(id);
      if (!removed) { await interaction.reply({ embeds: [errEmbed(`ID \`${id}\` introuvable dans la whitelist.`)], flags: MessageFlags.Ephemeral }); return; }
      await interaction.reply({ embeds: [successEmbed(`ID \`${id}\` retiré de la whitelist.`)] });
    } else {
      const list = getWhitelist();
      if (list.length === 0) { await interaction.reply({ embeds: [okEmbed("✅ Whitelist", "La whitelist est vide.")], flags: MessageFlags.Ephemeral }); return; }
      const desc = list.map((e, i) => `**${i + 1}.** ${e.tag} (\`${e.id}\`)`).join("\n");
      await interaction.reply({ embeds: [new EmbedBuilder().setColor(COLOR.green).setTitle(`✅ Whitelist (${list.length})`).setDescription(desc).setTimestamp()], flags: MessageFlags.Ephemeral });
    }
    return;
  }

  // ── /backup — Perm 4 ──────────────────────────────────────────────────────
  if (commandName === "backup") {
    if (permLevel < 4) { await interaction.reply({ embeds: [noPerm], flags: MessageFlags.Ephemeral }); return; }
    const sub = interaction.options.getSubcommand();
    if (sub === "create") {
      const backup = createBackup(guild, interaction.user.tag);
      await interaction.reply({ embeds: [successEmbed(`Sauvegarde créée ! ID : \`${backup.id}\``)] });
    } else if (sub === "list") {
      const backups = listBackups();
      if (backups.length === 0) { await interaction.reply({ embeds: [okEmbed("💾 Sauvegardes", "Aucune sauvegarde.")], flags: MessageFlags.Ephemeral }); return; }
      const desc = backups.slice(0, 10).map((b, i) => `**${i + 1}.** \`${b.id}\` — ${new Date(b.createdAt).toLocaleDateString("fr-FR")} par ${b.createdBy}`).join("\n");
      await interaction.reply({ embeds: [new EmbedBuilder().setColor(COLOR.blue).setTitle("💾 Sauvegardes").setDescription(desc).setTimestamp()], flags: MessageFlags.Ephemeral });
    } else {
      const id = interaction.options.getString("id", true);
      const ok = loadBackup(id);
      if (!ok) { await interaction.reply({ embeds: [errEmbed(`Sauvegarde \`${id}\` introuvable.`)], flags: MessageFlags.Ephemeral }); return; }
      await interaction.reply({ embeds: [successEmbed(`Sauvegarde \`${id}\` restaurée avec succès.`)] });
    }
    return;
  }

  // ── /maintenance — Perm 4 ─────────────────────────────────────────────────
  if (commandName === "maintenance") {
    if (permLevel < 4) { await interaction.reply({ embeds: [noPerm], flags: MessageFlags.Ephemeral }); return; }
    const statut = interaction.options.getString("statut", true);
    const message = interaction.options.getString("message") ?? "Le bot est actuellement en maintenance. Réessayez plus tard.";
    const on = statut === "on";
    updateConfig({ maintenanceMode: on, maintenanceMessage: message });
    await interaction.reply({ embeds: [okEmbed(`🔧 Maintenance ${on ? "activée" : "désactivée"}`, on ? `Message : ${message}` : "Le bot est de retour en ligne !")] });
    return;
  }

  // ── /règles — Perm 4 ──────────────────────────────────────────────────────
  if (commandName === "règles") {
    if (permLevel < 4) { await interaction.reply({ embeds: [noPerm], flags: MessageFlags.Ephemeral }); return; }
    const embed = new EmbedBuilder()
      .setColor(COLOR.purple)
      .setTitle("📜 Règlement du serveur Corbeaux")
      .setDescription(
        "Bienvenue sur le serveur **Corbeaux** ! Merci de respecter les règles suivantes :\n\n" +
        "**1.** Respectez tous les membres du serveur.\n" +
        "**2.** Aucun spam, flood ou publicité non autorisée.\n" +
        "**3.** Aucun contenu NSFW, raciste, ou offensant.\n" +
        "**4.** Respectez les décisions du staff.\n" +
        "**5.** Utilisez les bons salons pour chaque sujet.\n\n" +
        "En cliquant sur le bouton ci-dessous, vous acceptez le règlement et obtenez le rôle **Corbeaux+**."
      )
      .setTimestamp();
    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder().setCustomId("toggle_role_corbeaux").setLabel("✅ Accepter le règlement").setStyle(ButtonStyle.Success),
    );
    await interaction.reply({ content: "Règlement posté !", flags: MessageFlags.Ephemeral });
    await interaction.channel!.send({ embeds: [embed], components: [row] });
    return;
  }

  // ── /ticket-deban — Perm 4 ────────────────────────────────────────────────
  if (commandName === "ticket-deban") {
    if (permLevel < 4) { await interaction.reply({ embeds: [noPerm], flags: MessageFlags.Ephemeral }); return; }
    const embed = new EmbedBuilder()
      .setColor(COLOR.blue)
      .setTitle("🔓 Demande de déban")
      .setDescription("Tu as été banni et tu penses que c'était injuste ?\nClique sur le bouton ci-dessous pour ouvrir un ticket de déban.")
      .setTimestamp();
    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder().setCustomId("open_ticket_deban").setLabel("📋 Faire une demande de déban").setStyle(ButtonStyle.Primary),
    );
    await interaction.reply({ content: "Panel posté !", flags: MessageFlags.Ephemeral });
    await interaction.channel!.send({ embeds: [embed], components: [row] });
    return;
  }

  // ── /ticket-proposition — Perm 4 ──────────────────────────────────────────
  if (commandName === "ticket-proposition") {
    if (permLevel < 4) { await interaction.reply({ embeds: [noPerm], flags: MessageFlags.Ephemeral }); return; }
    const embed = new EmbedBuilder()
      .setColor(COLOR.purple)
      .setTitle("📺 Proposer un stream")
      .setDescription("Tu veux proposer un événement sportif à streamer sur notre serveur ?\nClique sur le bouton ci-dessous pour soumettre ta proposition.")
      .setTimestamp();
    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder().setCustomId("open_ticket_proposition").setLabel("📺 Proposer un stream").setStyle(ButtonStyle.Primary),
    );
    await interaction.reply({ content: "Panel posté !", flags: MessageFlags.Ephemeral });
    await interaction.channel!.send({ embeds: [embed], components: [row] });
    return;
  }

  // ── /owner — Perm 5 ───────────────────────────────────────────────────────
  if (commandName === "owner") {
    if (permLevel < 5) { await interaction.reply({ embeds: [noPerm], flags: MessageFlags.Ephemeral }); return; }
    const sub = interaction.options.getSubcommand();
    if (sub === "add") {
      const id = interaction.options.getString("id", true);
      const tag = interaction.options.getString("tag", true);
      addOwner({ id, tag, addedAt: new Date().toISOString(), addedBy: interaction.user.tag });
      await interaction.reply({ embeds: [successEmbed(`**${tag}** ajouté comme owner.`)] });
    } else if (sub === "remove") {
      const id = interaction.options.getString("id", true);
      const removed = removeOwner(id);
      if (!removed) { await interaction.reply({ embeds: [errEmbed(`ID \`${id}\` introuvable dans la liste des owners.`)], flags: MessageFlags.Ephemeral }); return; }
      await interaction.reply({ embeds: [successEmbed(`Owner \`${id}\` retiré.`)] });
    } else {
      const owners = getOwners();
      if (owners.length === 0) { await interaction.reply({ embeds: [okEmbed("👑 Owners", "Aucun owner enregistré.")], flags: MessageFlags.Ephemeral }); return; }
      const desc = owners.map((o, i) => `**${i + 1}.** ${o.tag} (\`${o.id}\`)`).join("\n");
      await interaction.reply({ embeds: [new EmbedBuilder().setColor(COLOR.dark).setTitle(`👑 Owners (${owners.length})`).setDescription(desc).setTimestamp()], flags: MessageFlags.Ephemeral });
    }
    return;
  }

  // ── /antilink — Perm 5 ────────────────────────────────────────────────────
  if (commandName === "antilink") {
    if (permLevel < 5) { await interaction.reply({ embeds: [noPerm], flags: MessageFlags.Ephemeral }); return; }
    const statut = interaction.options.getString("statut", true);
    const on = statut === "on";
    updateConfig({ antilink: on });
    await interaction.reply({ embeds: [okEmbed(`🔗 Antilink ${on ? "activé" : "désactivé"}`, on ? "Les liens seront supprimés automatiquement." : "Le filtre de liens est désactivé.")] });
    await sendLog(guild, "⚙️・logs", new EmbedBuilder().setColor(on ? COLOR.red : COLOR.green)
      .setTitle(`🔗 Antilink ${on ? "activé" : "désactivé"}`)
      .addFields({ name: "Par", value: interaction.user.tag, inline: true }).setTimestamp());
    return;
  }

  // ── /antispam — Perm 5 ────────────────────────────────────────────────────
  if (commandName === "antispam") {
    if (permLevel < 5) { await interaction.reply({ embeds: [noPerm], flags: MessageFlags.Ephemeral }); return; }
    const statut = interaction.options.getString("statut", true);
    const seuil = interaction.options.getInteger("seuil") ?? undefined;
    const intervalle = interaction.options.getInteger("intervalle") ?? undefined;
    const on = statut === "on";
    updateConfig({
      antispam: on,
      ...(seuil !== undefined && { antispamThreshold: seuil }),
      ...(intervalle !== undefined && { antispamInterval: intervalle * 1000 }),
    });
    await interaction.reply({ embeds: [okEmbed(`🚫 Antispam ${on ? "activé" : "désactivé"}`, on ? `Seuil: ${seuil ?? getConfig().antispamThreshold} msgs / ${intervalle ?? getConfig().antispamInterval / 1000}s` : "L'anti-spam est désactivé.")] });
    await sendLog(guild, "⚙️・logs", new EmbedBuilder().setColor(on ? COLOR.orange : COLOR.green)
      .setTitle(`🚫 Antispam ${on ? "activé" : "désactivé"}`)
      .addFields({ name: "Par", value: interaction.user.tag, inline: true }).setTimestamp());
    return;
  }

  // ── /antiraid — Perm 5 ────────────────────────────────────────────────────
  if (commandName === "antiraid") {
    if (permLevel < 5) { await interaction.reply({ embeds: [noPerm], flags: MessageFlags.Ephemeral }); return; }
    const statut = interaction.options.getString("statut", true);
    const seuil = interaction.options.getInteger("seuil") ?? undefined;
    const on = statut === "on";
    updateConfig({ antiraid: on, ...(seuil !== undefined && { antiraidThreshold: seuil }) });
    await interaction.reply({ embeds: [okEmbed(`🛡️ Antiraid ${on ? "activé" : "désactivé"}`, on ? `Seuil: ${seuil ?? getConfig().antiraidThreshold} joins / 10s` : "L'anti-raid est désactivé.")] });
    await sendLog(guild, "⚙️・logs", new EmbedBuilder().setColor(on ? COLOR.orange : COLOR.green)
      .setTitle(`🛡️ Antiraid ${on ? "activé" : "désactivé"}`)
      .addFields({ name: "Par", value: interaction.user.tag, inline: true }).setTimestamp());
    return;
  }

  // ── /antiraid-reset — Perm 5 ──────────────────────────────────────────────
  if (commandName === "antiraid-reset") {
    if (permLevel < 5) { await interaction.reply({ embeds: [noPerm], flags: MessageFlags.Ephemeral }); return; }
    if (!isRaidLockdown()) { await interaction.reply({ embeds: [errEmbed("Aucun lockdown anti-raid actif.")], flags: MessageFlags.Ephemeral }); return; }
    disableRaidLockdown();
    await interaction.reply({ embeds: [successEmbed("Lockdown anti-raid désactivé.")] });
    await sendLog(guild, "⚙️・logs", new EmbedBuilder().setColor(COLOR.green)
      .setTitle("🛡️ Antiraid — Lockdown levé")
      .addFields({ name: "Par", value: interaction.user.tag, inline: true }).setTimestamp());
    return;
  }

  } catch (err) {
    console.error("Erreur interaction:", err);
    try {
      if (interaction.isRepliable() && !interaction.replied && !interaction.deferred) {
        await interaction.reply({ embeds: [errEmbed("Une erreur interne est survenue.")], flags: MessageFlags.Ephemeral });
      }
    } catch { /* ignore */ }
  }
});

client.login(TOKEN);
