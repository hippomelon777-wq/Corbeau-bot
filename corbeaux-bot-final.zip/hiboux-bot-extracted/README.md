# 🦉 Hiboux Bot v3.0

Bot Discord de modération avancé pour le serveur Hiboux.

## Variables d'environnement

| Variable | Description |
|---|---|
| `DISCORD_BOT_TOKEN` | Le token de ton bot Discord |
| `ROLE_ID` | L'ID du rôle attribué à l'acceptation du règlement (ex: Hiboux+) |

Copie `.env.example` en `.env` et remplis les valeurs.

## Démarrage

```bash
npm install
npm run dev
```

## Structure des fichiers

```
hiboux-bot/
├── src/
│   ├── index.ts        ← Bot principal (commandes, interactions)
│   ├── blacklist.ts    ← Gestion de la blacklist
│   ├── warnings.ts     ← Gestion des avertissements
│   ├── whitelist.ts    ← Gestion de la whitelist
│   ├── owners.ts       ← Gestion des owners bot
│   ├── antispam.ts     ← Anti-spam, anti-link, anti-raid
│   ├── backup.ts       ← Système de sauvegarde
│   ├── data.ts         ← Config générale (maintenance, etc.)
│   └── ranks.ts        ← Système de rang / niveaux
├── data/               ← Données persistantes (JSON) — créé automatiquement
├── backups/            ← Sauvegardes — créé automatiquement
├── package.json
└── tsconfig.json
```

## Système de permissions

| Niveau | Rôle | Description |
|---|---|---|
| **Perm 5** | @paix | Owner bot — accès total |
| **Perm 4** | @admin | Administration complète |
| **Perm 3** | @+++ | Chef Modo — clear, rank |
| **Perm 2** | @++ | Modérateur — kick, ban, unban |
| **Perm 1** | @+ | Helpeur — warn, mute |
| **Perm 0** | Tout le monde | /help, /perm, /rank (soi-même) |

## Commandes

### Sanctions
| Commande | Perm | Description |
|---|---|---|
| `/warn @membre [raison]` | 1+ | Donner un avertissement |
| `/unwarn @membre [id]` | 1+ | Retirer un warn (ou tous) |
| `/warnlist @membre` | 1+ | Voir les warns d'un membre |
| `/mute @membre durée unité [raison]` | 1+ | Muter (max 28j) |
| `/unmute @membre` | 1+ | Démuter |
| `/kick @membre [raison]` | 2+ | Expulser |
| `/ban @membre [raison]` | 2+ | Bannir |
| `/unban id [raison]` | 2+ | Débannir |
| `/clear [nombre] [@membre]` | 3+ | Supprimer des messages |
| `/bl @membre [raison]` | 4+ | Blacklister + bannir |
| `/unbl id` | 4+ | Retirer de la blacklist |

### Système de rang
| Commande | Perm | Description |
|---|---|---|
| `/rank [@membre]` | 3+ | Voir le rang d'un membre |
| `/rank-top` | 3+ | Top 10 des membres |
| `/rank-set @membre points` | 4+ | Définir les points manuellement |

### Gestion des salons
| Commande | Perm | Description |
|---|---|---|
| `/lock [salon] [raison]` | 4+ | Verrouiller un salon |
| `/unlock [salon]` | 4+ | Déverrouiller un salon |
| `/renew [raison]` | 4+ | Renouveler le salon |

### Configuration
| Commande | Perm | Description |
|---|---|---|
| `/maintenance on\|off [message]` | 4+ | Mode maintenance |
| `/backup create\|list\|load` | 4+ | Sauvegardes |
| `/antilink on\|off` | 5 | Activer/désactiver antilink |
| `/antispam on\|off [seuil] [intervalle]` | 5 | Activer/désactiver antispam |
| `/antiraid on\|off [seuil]` | 5 | Activer/désactiver antiraid |
| `/antiraid-reset` | 5 | Lever le lockdown anti-raid |
| `/owner add\|remove\|list` | 5 | Gérer les owners |

### Divers
| Commande | Perm | Description |
|---|---|---|
| `/help` | Tous | Menu d'aide (6 pages, permanent) |
| `/perm` | Tous | Voir les niveaux de permission |

## Salons de logs

| Salon | Usage |
|---|---|
| `⚙️・logs` | Kick, ban, unban, clear, lock, unlock, renew, antilink, antispam, antiraid |
| `⚙️・logs•mute•unmute` | Warn, unwarn, mute, unmute |
| `⚙️・logs•bl` | Blacklist |
| `⚙️・logs•tickets•demande-deban` | Tickets déban |
| `⚙️・logs・proposition・stream` | Tickets propositions |
| `✅・suggestions•validé` | Propositions acceptées |

## Système de rang

- Chaque message rapporte **10 points** (cooldown 1 minute)
- Tous les **100 points** = 1 niveau
- Un message de félicitation est envoyé dans le salon lors d'un passage de niveau
- Classement visible avec `/rank-top`
